Stochastic Recurrent Neural Network for Multistep Time Series Forecasting:

1. data_loader files load the data from csv and convert them to the right format for modelling
2. gruvae contains the main model
3. train contains the class used for model training
4. multi_layer_perceptron contains code for an MLP
5. functions contains a few user-defined functions 
6. main is the main script used to call all the other scripts and train the models.
