import torch
import os
import pandas as pd
import matplotlib.pyplot as plt
from torch import optim
import torch.nn as nn
import numpy as np


os.chdir("C:/Users/tonyz/Desktop/GRUVAE/model")
import gruvae
import train
from data_loader_traffic import create_inout_sequences
from functions import sample_from_normal


os.chdir("C:/Users/tonyz/Desktop/GRUVAE/data/usingmean")

data = pd.read_csv("traffic.csv", nrows=1300)
data = data[["temp","rain_1h","snow_1h","clouds_all","traffic_volume"]] 


train_steps = 1000
val_steps = 200

tw = 20
train_size = train_steps/tw
validation_size = int(val_steps/tw)
test_size = int(len(data)//tw-train_size)

train_loader, test_loader,scaler = create_inout_sequences(data, tw, test_size)

torch.manual_seed(0)
gruVAE = gruvae.GRUVAE(4,128,128,1,30,4)
vae_trainer = train.AutoEncoderTrainer(gruVAE, optim.Adam, train_loader, test_loader, validation_size)
model_list, val_loss_list = vae_trainer.train_and_evaluate(300)

val, idx = min((val, idx) for (idx, val) in enumerate(val_loss_list))
model = model_list[idx]



def inverse(y, scaler):
    d = torch.cat([torch.tensor(y),torch.tensor(y),\
                  torch.tensor(y),torch.tensor(y),torch.tensor(y)], dim=-1).numpy()
    d = scaler.inverse_transform(d)
    return d


torch.manual_seed(0)
prev_x = test_loader.dataset.tensors[0][:validation_size][-1].to("cuda")
prev_y = test_loader.dataset.tensors[1][:validation_size][-1].to("cuda")


def compute_last_h(trials, prev_x, prev_y):
    errors = []
    h_list = []
    metric = nn.MSELoss()
    reconstruction_list = []
    #actual = actual.view(-1,1)
    for i in range(trials):
        _, reconstructions, hidden_states, _, _, _, _, _ = model(prev_x, prev_y)
        errors.append(metric(torch.stack(reconstructions).view(-1)[-1], prev_y[1:][-1]))
        h_list.append(hidden_states)
        reconstruction_list.append(torch.stack(reconstructions).detach().to("cpu").numpy())
        #reconstruction_list.append(scaler.inverse_transform(torch.stack(reconstructions).detach().numpy()))
    val, idx = min((val, idx) for (idx, val) in enumerate(errors))
    return h_list[idx][-1], reconstruction_list[idx]

last_val_h, reconstructions = compute_last_h(500, prev_x, prev_y)


pred_size = 30
new_x = test_loader.dataset.tensors[0][validation_size:].view(-1,4).to("cuda")
new_y = test_loader.dataset.tensors[1][validation_size:].view(-1)
new_y = inverse(new_y.view(-1,1),scaler)[:,4]

def make_predictions(model, pred_size, h_start, scaler, new_x):
    predicted_prices = []
    for i in range(pred_size):
        new_Z = model.Z_prior(h_start)
        new_Z = torch.chunk(new_Z, 2, dim=-1)
        Z_std = torch.exp(0.5*new_Z[1])
        new_Z = sample_from_normal(new_Z[0],Z_std)
        
        x_prime = torch.cat([new_Z, new_x[i].view(-1).float()])
        h_start,_ = model.run_GRU(x_prime,h_start)
        _,predicted_price,_ = model.reconstruct(h_start)
        predicted_price = predicted_price.to("cpu")
        predicted_price = inverse(predicted_price.view(-1,1),scaler)[:,4]
        predicted_prices.append(max(predicted_price,0))
    return predicted_prices
    

def trial(trials, model, hidden_states, pred_size, new_x):
    predictions = []
    upper_90 = []
    lower_90 = []
    upper_95 = []
    lower_95 = []
    mean = []
    for i in range(trials):
        predicted_prices = make_predictions(model, pred_size, hidden_states, scaler, new_x)
        predicted_prices = np.vstack(predicted_prices)
        predictions.append(predicted_prices)
       
    predictions = np.concatenate(predictions, axis=1)
        
    for j in range(pred_size):
        temp = predictions[j]
        upper_90.append(np.percentile(temp,95))
        lower_90.append(np.percentile(temp,5))
        upper_95.append(np.percentile(temp,97.5))
        lower_95.append(np.percentile(temp,2.5))
        mean.append(np.mean(temp))

    return upper_90, lower_90, upper_95, lower_95, mean


u_90, l_90, u_95, l_95, m = trial(500, model, last_val_h, pred_size, new_x)

##############################################################################
#run this block to plot graph
offset = 200
plt.rcParams["figure.figsize"] = (15,6)
actual_values = data["traffic_volume"].tolist()[:tw*(len(data)//tw)]

end_idx = val_steps+pred_size+train_steps
start_idx = end_idx-pred_size-val_steps
actual_range = actual_values[start_idx:end_idx]


validation_end = len(actual_range) - pred_size + 1
validation_start = validation_end - val_steps
min_val = min(actual_range[validation_start:validation_end])
max_val = max(actual_range[validation_start:validation_end])


plt.plot(actual_range,color="teal", label="actual")
plt.plot([i+val_steps for i in range(len(m))],m, color="deeppink", label="mean prediction")
plt.fill_between([i+val_steps for i in range(len(m))], u_95, l_95,
                 color='deeppink', alpha=0.2, label="95% confidence interval")
plt.fill_between([i+val_steps for i in range(len(m))], u_90, l_90,
                 color='cyan', alpha=0.2, label="90% confidence interval")

plt.xlabel("observation point")
plt.ylabel("traffic volume")

plt.legend(loc="lower left", prop={"size":15})
plt.grid()
ticks,labels = plt.xticks()
ticks = np.array(list(ticks)[1:-1]).astype(int)
labels = ticks+1001
plt.xticks(ticks, labels)

