import torch
import torch.distributions as distribution

def init_network_weights(model):
    if type(model) == torch.nn.Linear:
        torch.nn.init.xavier_uniform_(model.weight)
        if model.bias is not None:
            model.bias.data.fill_(0.0)
            
def normal_distribution(mu, var):

    #var = torch.exp(0.5*logvar)
    normal = distribution.Normal(mu, var)
    return normal


def sample_from_normal(mu, var):
    normal = normal_distribution(mu, var)
    sample = normal.rsample()
    return sample

def loss_function(recon, data, Z_prior, Z_posterior, var = 1.0):

    normal = distribution.Normal(recon, var)
    log_likelihood = normal.log_prob(data).sum()

    
    prior = normal_distribution(Z_prior[0],Z_prior[1])
    posterior = normal_distribution(Z_posterior[0],Z_posterior[1])
    
    #priorh = normal_distribution(torch.zeros_like(h_mean_var[0]),torch.ones_like(h_mean_var[1]))
    #posteriorh = normal_distribution(h_mean_var[0],h_mean_var[1])
    
    KL = distribution.kl_divergence(posterior,prior).sum()
    #KL3 = distribution.kl_divergence(posteriorh,priorh).sum()

    return -log_likelihood + KL
    #return -log_likelihood

