import torch
import torch.nn as nn
from multi_layer_perceptron import MLP
from functions import sample_from_normal

class GRUCell(nn.Module):
    def __init__(self, input_size, hidden_size, bias=True):

        super().__init__()

        self.lin_x = torch.nn.Linear(input_size, hidden_size * 3, bias=bias)
        self.lin_r = torch.nn.Linear(hidden_size, hidden_size, bias=False)
        self.lin_z = torch.nn.Linear(hidden_size, hidden_size, bias=False)
        self.lin_g = torch.nn.Linear(hidden_size, hidden_size, bias=False)

    def forward(self, x, h):
        xr, xz, xg = torch.chunk(self.lin_x(x), 3, dim=-1)
        r = torch.sigmoid(xr + self.lin_r(h))
        z = torch.sigmoid(xz + self.lin_z(h))
        g = torch.tanh(xg + self.lin_g(r * h))

        h_new = z * h + (1-z) * g
        dh = (1-z) * (g-h)
        return h_new, dh

class GRUVAE(nn.Module):

    def __init__(self, input_size, gru_hidden_size, inf_gru_hidden_size, output_size, Z_size, n_mlp, bias=True):
        super().__init__()

        # Attributes
        self.input_size = input_size #size of gru
        self.gru_hidden_size = gru_hidden_size #hidden size of gru-vae
        self.inf_gru_hidden_size = inf_gru_hidden_size #hidden size of gru for Z inference
        self.output_size = output_size
        self.Z_size = Z_size #size of auxillary random var Z
        self.n_mlp = n_mlp #number of mlp layers
        
        # Prior of Z
        self.Z_prior = MLP(self.gru_hidden_size, self.gru_hidden_size, self.Z_size*2, self.n_mlp)
        # Posterior of Z
        #self.gru_Z = nn.GRU(self.input_size, self.inf_gru_hidden_size, 1)
        self.gru_Z = nn.GRU(1, self.inf_gru_hidden_size, 1)
        self.Z_post = nn.Linear(self.inf_gru_hidden_size, self.Z_size * 2)
        
        # main gru model
        self.gru = GRUCell(self.Z_size+self.input_size, self.gru_hidden_size, bias=bias)
        
        # emission model
        #self.emission = MLP(self.gru_hidden_size,self.gru_hidden_size,self.output_size*2,self.n_mlp)
        self.emission = MLP(self.gru_hidden_size,self.gru_hidden_size,self.output_size,self.n_mlp)
        
        # map hidden state to option price
        self.map = nn.Linear(self.gru_hidden_size, self.output_size*2)
        

    def Z_inference(self, gru_hidden_state):
        Z_mean_var = self.Z_post(gru_hidden_state)
        Z_mean_var = torch.chunk(Z_mean_var, 2, dim=-1)
        Z_std = torch.exp(0.5*Z_mean_var[1]) # convert logvar to std
        #Z_std = Z_mean_var[1]
        Z = sample_from_normal(Z_mean_var[0],Z_std)
        return Z, (Z_mean_var[0],Z_std)
    
    # returns next gru hidden state
    def run_GRU(self, x_prime, gru_hidden_state):

        gru_output,dh = self.gru(x_prime, gru_hidden_state)             
        return gru_output,dh
    
    
    def reconstruct(self, gru_hidden_state):

        reconstruction = self.emission(gru_hidden_state)
        #reconstruction = self.map(gru_hidden_state)
        #reconstruction = torch.chunk(reconstruction, 2, dim=-1)
        #mean = torch.exp(reconstruction[0])
        #mean = reconstruction[0]
        #reconstruction_std = torch.exp(0.5*reconstruction[1])
        #reconstruction_std = reconstruction[1]
        #reconstruct = sample_from_normal(mean,reconstruction_std)
        return (reconstruction,reconstruction,0)
    

    def run_GRUVAE(self, gru_hidden_size, inf_gru_hidden_size,x, y, h=False):

        dhs = []
        Zs, Z_posteriors, Z_priors = [], [], [] 
        y = y.view(len(y),1,1)
        h_sequence = self.gru_Z(y.float())[0]

        if h is not False:
            h=h
        else:
            h = torch.zeros(gru_hidden_size).to("cuda")
            #h = h_sequence_reverse
            #h = torch.randn(gru_hidden_size)
        hidden_states = [h]
        
        for t in range(1,len(y)):
            #x_prime = torch.cat([h,x[t].view(-1).float()])
            Z_prior = self.Z_prior(h)   
            Z_prior = torch.chunk(Z_prior, 2, dim=-1)
            Z_std = torch.exp(0.5*Z_prior[1])
            #Z_std = abs(Z_prior[1])
            Z_priors.append((Z_prior[0],Z_std))
            
            Z, Z_posterior = self.Z_inference(h_sequence[t].view(inf_gru_hidden_size))
            Z_posteriors.append(Z_posterior)
            Zs.append(Z)
            
            x_prime = torch.cat([Z,x[t].view(-1).float()])
            h_new,dh = self.run_GRU(x_prime,h)
            hidden_states.append(h_new)
            dhs.append(dh)
            h = h_new

        return Z_priors, Zs, Z_posteriors, hidden_states,dhs
      
    def forward(self, x, y, h=False):

        Z_priors, Zs, Z_posteriors, hidden_states,dhs = self.run_GRUVAE(self.gru_hidden_size,self.inf_gru_hidden_size,x,y,h)
        means = []
        samples = []
        for time in range(1,len(x)):
            mean,sample,std = self.reconstruct(hidden_states[time])
            means.append(mean)
            samples.append(sample)

        return means, samples, hidden_states, Z_priors, Zs, Z_posteriors, dhs, std
        


