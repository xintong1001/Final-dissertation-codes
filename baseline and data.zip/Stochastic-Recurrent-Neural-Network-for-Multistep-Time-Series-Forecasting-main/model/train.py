import torch
from functions import loss_function
import torch.nn as nn
import copy

class AutoEncoderTrainer:
    """AutoEncoder Training class."""
    def __init__(self, model, optimizer, train_loader, test_loader, validation_size): 
        """Initialization."""
        self.model = model
        self.device = torch.device("cuda" if torch.cuda.is_available() else
                                   "cpu")
        self.optimizer = optimizer(self.model.parameters(), lr=0.001)
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.validation_size = validation_size
                
        
    def train_iter(self):
        """Single pass through the training data."""
        self.model.train()
        x = self.train_loader.dataset.tensors[0].to(self.device)
        y = self.train_loader.dataset.tensors[1].to(self.device)
        loss = 0
        self.optimizer.zero_grad()
        for d in range(len(x)):
            means,reconstructions, hidden_states, Z_priors, Zs, Z_posteriors, dhs,_ = self.model(x[d],y[d])
            for i in range(len(reconstructions)):
                L = loss_function(reconstructions[i], y[d][i+1].view(reconstructions[i].size()), Z_priors[i], Z_posteriors[i], var = 1.0)
                loss += L
        loss.backward()
        self.optimizer.step() 
        copymodel = copy.deepcopy(self.model)
        return loss, hidden_states, means, reconstructions, copymodel
    
    def val_iter(self):
        self.model.eval()
        with torch.no_grad():
            val_x = self.test_loader.dataset.tensors[0][:self.validation_size].to(self.device)
            val_y = self.test_loader.dataset.tensors[1][:self.validation_size].to(self.device)
            
            metric = nn.MSELoss()
            val_loss = 0
            
            for i in range(len(val_x)):
                _, reconstructions, hidden_states, _, _, _, _, _ = self.model(val_x[i],val_y[i])
                val_loss += metric(torch.stack(reconstructions).view(-1), val_y[i][1:]).detach().float()
                
        return val_loss 
            
    def train_and_evaluate(self, epochs, params_select = False):
        """Run training and evaluation."""
        self.model.to(self.device)
        model_list=[]
        val_loss_list=[]
        for epoch in range(epochs):
            train_loss, hidden_states,_,_,model = self.train_iter()
            val_loss = self.val_iter()
            model_list.append(model)
            val_loss_list.append(val_loss)
            
            if not params_select:
                print(f"\tEpoch: {epoch}, Train Loss: {train_loss:.4f}, Validation Loss: {val_loss:.4f}")
                            
        return model_list, val_loss_list

            
        
        
        

    
    
    
    
  